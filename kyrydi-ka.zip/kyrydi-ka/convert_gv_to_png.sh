#!/bin/bash

RESULTS_DIR="results"

mkdir -p "$RESULTS_DIR/png"

echo "Deleting old PNG..."
rm -f "$RESULTS_DIR/png"/*.png

echo "Converting .gv to .png..."
for gvfile in "$RESULTS_DIR"/*.gv; do
    [ -e "$gvfile" ] || continue

    filename=$(basename "$gvfile" .gv)
    pngfile="$RESULTS_DIR/png/${filename}.png"
    dot -Tpng "$gvfile" -o "$pngfile"
    echo "Converted $gvfile -> $pngfile"
done

echo "Over"

