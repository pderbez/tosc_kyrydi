#ifndef KEY_ABS_AVERAGE_HPP
#define KEY_ABS_AVERAGE_HPP

#include <vector>
#include <map>

class Cipher; 

// Un groupe de din ayant le même nombre de solutions pour le dout considéré
struct SimpleDinGroup {
    unsigned nb_solutions;          // ex : 1, 2, 4, 8...
    std::vector<unsigned> dins;     // valeurs de din (entiers) avec ce nb de solutions
};

// Map : dout (pattern 0/1/2) -> groupes de din
using SimpleSboxMap =
    std::map<std::vector<unsigned>, std::vector<SimpleDinGroup>>;

/**
 * Calcule, pour une S-box donnée et un pattern de sortie deltaout (0/1/2),
 * les différentes valeurs possibles de din = x^y, en les regroupant par
 * nombre de solutions (# { (x,y) | S[x]^S[y] respecte deltaout et x^y = din }).
 *
 * deltaout : vecteur de taille lenSB, avec 0/1/2 (2 = joker).
 * sbox     : table de taille 2^{lenSB}.
 */
SimpleSboxMap compute_simple_sbox_map(
    const std::vector<unsigned>& sbox,
    const std::vector<unsigned>& deltaout
);

void print_simple_sbox_map(const SimpleSboxMap& sm, unsigned len);

void run_key_absorption_average( Cipher& myCipher, const std::vector<unsigned>& sbox_indices, double bound_time, double bound_mem, double bound_off, bool be_slow);

#endif
