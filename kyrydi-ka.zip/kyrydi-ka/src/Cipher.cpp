    //
    //  Cipher.cpp
    //
    //
    //  Created by Heim on 19/06/2023.
    //
#include <set>
#include "Cipher.hpp"
#include "key_abs.hpp"
#include "key_abs_average.hpp" 

using namespace std;

ostream& operator<<(ostream & flux, Cipher const & c) {
    flux << "SB :" << endl;
    flux << "len of sbox in bits = " << c.lenSB << endl;
    for (unsigned i = 0; i < c.sizeSB; i++)
        flux << c.SB[i] << " ";



    flux << endl << endl << endl << "PERMutation :" << endl;
    for (unsigned i = 0; i < c.sizeBlock; i++){
        cout << c.PERM[i] << " ";
    }

    flux << endl << endl << "block size = " << c.sizeBlock << endl << endl;
    {
        flux << "DDT :" << endl;
        for (unsigned din = 0; din < c.sizeSB; din++){
            for (unsigned dout = 0; dout < c.sizeSB; dout++)
                flux << c.DDT[din][dout] << " ";
            flux << endl;
        }
    }
    flux << endl << "nr rounds = " << c.nrR << endl << endl << "DINa :" << endl;
    for (unsigned i = 0; i < c.sizeBlock; i++){
        if (c.DINa[i] == 2)
            flux << "*";
        else
            flux << c.DINa[i];
    }
    flux << endl << endl << "DINb :" << endl;
    for (unsigned i = 0; i < c.sizeBlock; i++){
        if (c.DINb[i] == 2)
            flux << "*";
        else
            flux << c.DINb[i];
    }
    flux << endl << endl << "DOUTb:" << endl;
    for (unsigned i = 0; i < c.sizeBlock; i++){
        if (c.DOUTb[i] == 2)
            flux << "*";
        else
            flux << c.DOUTb[i];
    }
    flux << endl << endl << "DOUTa :" << endl;
    for (unsigned i = 0; i < c.sizeBlock; i++){
        if (c.DOUTa[i] == 2)
            flux << "*";
        else
            flux << c.DOUTa[i];
    }
    flux << endl << endl << "DKEY :" << endl;
    for (unsigned i = 0; i < c.sizeBlock*(c.nrR+1); i++){
        if (c.DKEY[i] == 2)
            flux << "*";
        else
            flux << c.DKEY[i];
    }
    flux << endl << endl << "nrSBp = " << c.nrSBp << ", nrSBc = " << c.nrSBc << endl << endl;
    return flux;
}

Cipher::Cipher(ifstream & input_file, double N, bool be_slow) : beslow(be_slow), Npairs (N) {
    string temp;
    istringstream buffer;
    unsigned i;
    while(getline(input_file, temp)){
            //SB
        if( temp.rfind("SB", 0) == 0){

            for (i = 0; i < 2; i++)
                temp.erase(temp.begin());
            buffer = istringstream(temp); //pour pouvoir itérer après dessus
            SB = vector<unsigned>((istream_iterator<unsigned>(buffer)), istream_iterator<unsigned>()); //trouver les unsigned et les mettre ds le vecteur SB
            sizeSB = (SB).size();
            lenSB = log2(sizeSB);
        }
            //PERM
        else if( temp.rfind("PERM", 0) == 0 ){
            for (i = 0; i < 4; i++)
                temp.erase(temp.begin());
            buffer = istringstream(temp);
            PERM = vector<unsigned>((istream_iterator<unsigned>(buffer)), istream_iterator<unsigned>());
            sizeBlock = (PERM).size();

        }
            //nrR
        else if( temp.rfind("nrR", 0) == 0 ){
            for (i = 0; i < 3; i++)
                temp.erase(temp.begin());
            buffer = istringstream(temp);
            nrR = vector<unsigned>((istream_iterator<unsigned>(buffer)), istream_iterator<unsigned>())[0];
        }
            //DINb
        else if( temp.rfind("DINb", 0) == 0 ){
            for (i = 0; i < 4; i++)
                temp.erase(temp.begin());
            buffer = istringstream(temp);
            DINb = vector<unsigned>((istream_iterator<unsigned>(buffer)), istream_iterator<unsigned>());

        }
            //DINa
        else if( temp.rfind("DINa", 0) == 0 ){
            for (i = 0; i < 4; i++)
                temp.erase(temp.begin());
            buffer = istringstream(temp);
            DINa = vector<unsigned>((istream_iterator<unsigned>(buffer)), istream_iterator<unsigned>());
        }
            //DOUTb
        else if( temp.rfind("DOUTb", 0) == 0 ){
            for (i = 0; i < 5; i++)
                temp.erase(temp.begin());
            buffer = istringstream(temp);
            DOUTb = vector<unsigned>((istream_iterator<unsigned>(buffer)), istream_iterator<unsigned>());
        }
            //DOUTa
        else if( temp.rfind("DOUTa", 0) == 0 ){
            for (i = 0; i < 5; i++)
                temp.erase(temp.begin());
            buffer = istringstream(temp);
            DOUTa = vector<unsigned>((istream_iterator<unsigned>(buffer)), istream_iterator<unsigned>());
        }
            //DKEY
        else if( temp.rfind("DKEY", 0) == 0 ){
            for (i = 0; i < 4; i++)
                temp.erase(temp.begin());
            buffer = istringstream(temp);
            DKEY = vector<unsigned>((istream_iterator<unsigned>(buffer)), istream_iterator<unsigned>());
        }
            //nrSBp
        else if( temp.rfind("nrSBp", 0) == 0 ){
            for (i = 0; i < 5; i++)
                temp.erase(temp.begin());
            buffer = istringstream(temp);
            nrSBp = vector<unsigned>((istream_iterator<unsigned>(buffer)), istream_iterator<unsigned>())[0];
        }
            //nrSBc
        else if( temp.rfind("nrSBc", 0) == 0 ){
            for (i = 0; i < 5; i++)
                temp.erase(temp.begin());
            buffer = istringstream(temp);
            nrSBc = vector<unsigned>((istream_iterator<unsigned>(buffer)), istream_iterator<unsigned>())[0];
        }
            //KS
        else if (temp.rfind("KS",0) == 0)
            getKS(input_file);
    }

    if (DKEY.empty()) DKEY = vector<unsigned>((nrR + 1)*sizeBlock, 0);

    InvPERM = vector<unsigned>(sizeBlock);
    for (unsigned i = 0; i < sizeBlock; i++)
        InvPERM[PERM[i]] = i;
    
    matKS = Matrix(KS);
    key_abs = false;

    knownkeybits = vector<uint8_t> (sizeBlock*(nrR + 1));
    for (unsigned i = 0; i < sizeBlock*(nrR + 1); ++i) knownkeybits[i] = matKS.isKnown(i);

    computeDDT();
    propagation();
    printProp();
    fillSb();

    getchar();
}

void Cipher::computeDDT() {
    DDT = vector<vector<unsigned>> (sizeSB,vector<unsigned>(sizeSB, 0));
    for (unsigned din = 0; din < sizeSB; din++){
        for (unsigned x = 0; x < sizeSB; x++){
            DDT[din][SB[x] ^ SB[x ^ din]] += 1;
        }
    }
}

void Cipher::getKS(ifstream & input_file){
    KS = vector<vector<unsigned>>() ;

    string temp;
    istringstream buffer;
    vector<unsigned> vect;

    for (;;){ //in line i, we put the ith key schedule equation of the file
        getline(input_file, temp);
        if (temp.empty()) {
            cout << "Key schedule loaded. It contains " << KS.size() << " equations" << endl;
            return;
        }
        if (temp[0] == 'k'){
            temp.erase(remove(temp.begin(),temp.end(), '+'), temp.end());
            temp.erase(remove(temp.begin(),temp.end(), 'k'), temp.end());
            replace(temp.begin(), temp.end(), '[', ' ');
            replace(temp.begin(), temp.end(), ']', ' ');
            buffer = istringstream(temp);
            vect = vector<unsigned>((istream_iterator<unsigned>(buffer)), istream_iterator<unsigned>());
            vector<unsigned> tmp;
            for (unsigned ct = 0; ct < vect.size(); ct+=2){ //vect.size() is always an even number, vect.size()/2 is equal to the number of key bits appearing in the equation, ie the number of 1 in the vector
                tmp.push_back(vect[ct]*sizeBlock + vect[ct + 1]);
            }
            KS.emplace_back(move(tmp));
        }
        else {
          cout << "Key schedule loaded. It contains " << KS.size() << " equations" << endl;
          return;
        }
    }
}

void Cipher::propagation(){
    unsigned bitsToZero,bitsToOne;
    vector < unsigned > din,dout;
    vector <unsigned> Sboxes_for_key_abs;

    // plaintext
    prop = vector < unsigned > ((2*nrR)*sizeBlock,3);
    for (unsigned i = 0; i < sizeBlock; i++){
      if (nrSBp > 0) {
        prop[(2*nrSBp-1)*sizeBlock + i] = DINa[i];
        prop[(2*nrSBp-2)*sizeBlock + i] = DINb[i];
      }
      else {
        prop[i] = DINa[i];
      }
    }

    // rounds before distinguisher
    for (unsigned i = 0; i < nrSBp ; i++){
        unsigned l = nrSBp - 1 - i;
        for (unsigned j = 0; j < sizeBlock/lenSB ; j++){
            if (all_of(&prop[(2*l+1)*sizeBlock+j*lenSB],
                       &prop[(2*l+1)*sizeBlock+j*lenSB+lenSB],
                       [](unsigned x){return x == 0;})){
                for (unsigned k = 0; k < lenSB; k++){
                    prop[2*l*sizeBlock + j*lenSB + k] = 0;
                }
            }
            else{
                dout = getDiff(2*l+1,j,prop);
                bitsToZero = findBitsToZeroBackward(dout);
                bitsToOne = findBitsToOneBackward(dout);
                for (unsigned k = 0; k < lenSB; k++){
                    if ( (((bitsToZero>>k)&0x1) == 0) ){
                        if (prop[2*l*sizeBlock + j*lenSB + k] == 3)
                            prop[2*l*sizeBlock + j*lenSB + k] = 0;
                    }
                    else if( (((bitsToOne>>k)&0x1) == 1)  ){
                        if (prop[2*l*sizeBlock + j*lenSB + k] == 3)
                            prop[2*l*sizeBlock + j*lenSB + k] = 1;
                    }
                    else{
                        if (prop[2*l*sizeBlock + j*lenSB + k] == 3)
                            prop[2*l*sizeBlock + j*lenSB + k] = 2;
                    }
                }
            }
        }

        if (l != 0){
            for(unsigned j = 0; j < sizeBlock; j++){
                if((prop[2*l*sizeBlock + j] < 2) && (DKEY[l*sizeBlock + j] < 2))
                    prop[(2*l-1)*sizeBlock + InvPERM[j]] = prop[2*l*sizeBlock + j] ^ DKEY[l*sizeBlock+j];
                else
                    prop[(2*l-1)*sizeBlock + InvPERM[j]] = 2;
            }
        }
    }

    // after distinguisher
    for (unsigned i = 0; i < sizeBlock; i++){
      if (nrSBc > 0) {
          prop[2*(nrR - nrSBc)*sizeBlock + i] = DOUTb[i];
          prop[(2*(nrR - nrSBc)+1)*sizeBlock + i] = DOUTa[i];
      }
      else {
        prop[(2*nrR + 1)*sizeBlock + i] = DOUTb[i];
      }
    }

    for (unsigned i = 0; i < nrSBc ; i++){
        unsigned l = nrR - nrSBc + i;
        for (unsigned j = 0; j < sizeBlock/lenSB ; j++){
            if (all_of(&prop[(2*l)*sizeBlock+j*lenSB],
                       &prop[(2*l)*sizeBlock+j*lenSB+lenSB],
                       [](unsigned x){return x == 0;})){
                for (unsigned k = 0; k < lenSB; k++){
                    prop[(2*l+1)*sizeBlock + j*lenSB + k] = 0;
                }
            }
            else{
                dout = getDiff(2*l,j,prop);
                bitsToZero = findBitsToZeroForward(dout);
                bitsToOne = findBitsToOneForward(dout);
                for (unsigned k = 0; k < lenSB; k++){
                    if ( (((bitsToZero>>k)&0x1) == 0) ){
                        if (prop[(2*l+1)*sizeBlock + j*lenSB + k] == 3)
                            prop[(2*l+1)*sizeBlock + j*lenSB + k] = 0;
                    }
                    else if( (((bitsToOne>>k)&0x1) == 1)  ){
                        if (prop[(2*l+1)*sizeBlock + j*lenSB + k] == 3)
                            prop[(2*l+1)*sizeBlock + j*lenSB + k] = 1;
                    }
                    else{
                        if (prop[(2*l+1)*sizeBlock + j*lenSB + k] == 3)
                            prop[(2*l+1)*sizeBlock + j*lenSB + k] = 2;
                    }
                }
            }
        }
        if ((l+1) < nrR){
            for(unsigned j = 0; j<sizeBlock; j++){
                if((prop[(2*l+1)*sizeBlock + j] < 2) && (DKEY[(l+1)*sizeBlock + j] < 2))
                    prop[2*(l+1)*sizeBlock + PERM[j]] = prop[(2*l+1)*sizeBlock + j] ^ DKEY[(l+1)*sizeBlock + j];
                else
                    prop[2*(l+1)*sizeBlock + PERM[j]] = 2;
            }
        }
    }

    // === Detect S-boxes available for tree guessing ===
    allowed_first_round_sboxes.clear();
    allowed_last_round_sboxes.clear();
    std::vector<unsigned> first_round_sboxes;
    std::vector<unsigned> last_round_sboxes;

    // First-round
    for (unsigned j = 0; j < sizeBlock / lenSB; ++j) {
        unsigned active_count = 0;
        for (unsigned k = 0; k < lenSB; ++k)
            if (prop[1 * sizeBlock + j * lenSB + k] > 0) active_count++;

        if (active_count == 1) {
            first_round_sboxes.push_back(j);
            allowed_first_round_sboxes.push_back(j);
        }
    }

    // Last-round
    for (unsigned j = 0; j < sizeBlock / lenSB; ++j) {
        unsigned active_count = 0;
        for (unsigned k = 0; k < lenSB; ++k)
            if (prop[2 * (nrR - 1) * sizeBlock + j * lenSB + k] > 0) active_count++;

        if (active_count == 1) {
            unsigned global_index = j + (nrR - 1) * (sizeBlock / lenSB);
            last_round_sboxes.push_back(global_index);
            allowed_last_round_sboxes.push_back(global_index);
        }
    }

    std::cout << "\n=== S-boxes available for tree guessing ===\n";
    std::cout << "First-round S-boxes : ";
    for (unsigned s : first_round_sboxes) std::cout << s << " ";
    std::cout << "\nLast-round S-boxes  : ";
    for (unsigned s : last_round_sboxes) std::cout << s << " ";
    std::cout << "\n======================================\n\n";
}


vector < unsigned > Cipher::getDiff(unsigned i, unsigned j, vector <unsigned> & v) const{
    vector < unsigned > d (lenSB);
    for (unsigned k = 0; k < lenSB; k++)
        d[k] = v[i*sizeBlock + lenSB*j + k];
    return d;
}

unsigned Cipher::findBitsToZeroForward(vector < unsigned > din) const{
    unsigned bitsToZero = 0, i = 0, dout = 0;
    vector < unsigned > possible_din = possibleVectors(din);
    for (i = 0; i < possible_din.size(); i++){
        for (dout = 0; dout < sizeSB; dout++){
            if (DDT[possible_din[i]][dout] != 0)
                bitsToZero |= dout;
        }
    }
    return bitsToZero;
}

unsigned Cipher::findBitsToOneForward(vector < unsigned > din) const{
    unsigned bitsToOne = (sizeSB-1), i = 0, dout = 0;
    vector < unsigned > possible_din = possibleVectors(din);
    for (i = 0; i < possible_din.size(); i++){
        for (dout = 0; dout < sizeSB; dout++){
            if (DDT[possible_din[i]][dout] != 0)
                bitsToOne &= dout;
        }
    }
    return bitsToOne;
}

unsigned Cipher::findBitsToZeroBackward(vector < unsigned > dout) const{
    unsigned bitsToZero = 0;
    vector < unsigned > possible_dout = possibleVectors(dout);
    for (unsigned i = 0; i < possible_dout.size(); i++){
        for (unsigned din = 0; din < sizeSB; din++){
            if (DDT[din][possible_dout[i]] != 0)
                bitsToZero |= din;
        }
    }
    return bitsToZero;
}

unsigned Cipher::findBitsToOneBackward(vector < unsigned > dout) const{
    unsigned bitsToOne = (sizeSB-1), i = 0, din = 0;
    vector < unsigned > possible_dout = possibleVectors(dout);
    for (i = 0; i < possible_dout.size(); i++){
        for (din = 0; din < sizeSB; din++){
            if (DDT[din][possible_dout[i]] != 0)
                bitsToOne &= din;
        }
    }
    return bitsToOne;
}


void Cipher::fillSb(){

    unsigned r,j,ct = 0;
    vector<unsigned> din, dout;
    solSboxes = vector<double> (nrR*(sizeBlock/lenSB), 0.0);
    solSboxesIn = vector<double> (nrR*(sizeBlock/lenSB), 0.0);

    activitySBT = vector<unsigned>(nrR*(sizeBlock/lenSB));
    filterSB = vector<double>(nrR*(sizeBlock/lenSB));


        // For rounds before DeltaX
    for (r = 0; r < nrR; r++){ //for each sb layer before the diff
        for(j = 0;  j < sizeBlock/lenSB; j++){ //for each sb
            int act = 0;
            for(unsigned k = 0; k<lenSB; k++){
                if(prop[2*r*sizeBlock + j*lenSB + k]) act = 1;
            }
            activitySBT[ct] = act;
            ct++;
    }
    }

    // === OVERRIDE POUR KEY ABSORPTION ===
    if (key_abs) {
        for (unsigned idx : sbox_indices) {
            if (idx < activitySBT.size())
                activitySBT[idx] = 1;
        }
    }

    ct = 0;

    double save_filter = 0.0;


    for (r = 0; r < nrSBp; r++){ //for each sb layer before the diff
        for(j = 0;  j < sizeBlock/lenSB; j++){ //for each sb
            din = getDiff(2*r,j, prop);
            dout = getDiff(2*r+1,j,prop);
            solSboxes[ct] = log2(getNrSol(din, dout));

            if(activitySBT[ct] == 1){

                vector<pair<unsigned, unsigned>> my_inputs;

                for (unsigned x = 0; x < 1u << lenSB; ++x) {
                  for (unsigned y = 0; y < 1u << lenSB; ++y) {
                    bool add = true;
                    auto diff_in = x^y;
                    for (unsigned b = 0; b < lenSB; ++b) if (din[b] != 2 && ((diff_in >> b) & 1) != din[b]) add = false;
                    auto diff_out = SB[x]^SB[y];
                    for (unsigned b = 0; b < lenSB; ++b) if (dout[b] != 2 && ((diff_out >> b) & 1) != dout[b]) add = false;
                    if (add) my_inputs.emplace_back(x,y);
                  }
                }
                set<unsigned> set_of_inputs;
                unsigned expected_size = 0;
                for (auto const & my_pair : my_inputs) {
                  unsigned x = 0, i = 0;
                  for (unsigned b = 0; b < lenSB; ++b) {
                    if (isKnownKeyBit(r*sizeBlock + j*lenSB + b)) {
                      x |= ((my_pair.first >> b) & 1) << i;
                      i += 1;
                      x |= ((my_pair.second >> b) & 1) << i;
                      i += 1;
                    }
                    else {
                      x |= (((my_pair.first >> b) & 1) ^ ((my_pair.second >> b) & 1)) << i;
                      i += 1;
                    }
                  }
                  expected_size = i;
                  set_of_inputs.emplace(x);
                }
                for (unsigned i = 0; i < lenSB; ++i) if (din[i] != 2) expected_size -= 1;
                double cpt = set_of_inputs.size();
                cpt /= 1u << expected_size;


                solSboxes[ct] -= log2(cpt);

                if(!beslow || r != 0) {
                  filterSB[ct] = -log2(cpt);
                  solSboxesIn[ct] = expected_size - filterSB[ct];
                }
                else {
                  filterSB[ct] = 0;
                  solSboxesIn[ct] = expected_size;
                  Npairs += log2(cpt);
                  save_filter -= log2(cpt);
                }
                
            }
            // === Key absorption override on filter ===
            if (key_abs && getKeyAbsType() == KeyAbsType::AVERAGE) {
                if (std::find(sbox_indices.begin(), sbox_indices.end(), ct) != sbox_indices.end()) {
                    bool din_is_zero = true;
                    for (unsigned b = 0; b < lenSB; b++) {
                        if (din[b] != 0) { din_is_zero = false; break; }
                    }

                    if (din_is_zero) {
                        solSboxes[ct] -= 1.0;   // reduce for din = 0
                    } else {
                        solSboxes[ct] = 0.0;    // force to zero for din != 0
                    }
                }
            }
            ct++;
        }
    }
    //getchar();
        // For middle rounds, that are of no interest to us
    for (r = nrSBp; r < nrR - nrSBc; r++){ //for each sb layer before the diff
        for(j = 0;  j < sizeBlock/lenSB; j++){ //for each sb
            solSboxes[ct] = 0;
            ct++;
        }
    }
        // For rounds after DeltaY

    //cout << "filtres de la fin :" << endl;
    for (r = nrR - nrSBc; r < nrR; r++){ //for each sb after the diff
        for(j = 0;  j < sizeBlock/lenSB; j++){ //for each sb
            din = getDiff(2*r,j,prop);
            dout = getDiff(2*r+1,j,prop);
            solSboxes[ct] = log2(getNrSol(din, dout));

            if(activitySBT[ct] == 1){

              vector<pair<unsigned, unsigned>> my_inputs;

              for (unsigned x = 0; x < 1u << lenSB; ++x) {
                for (unsigned y = 0; y < 1u << lenSB; ++y) {
                  bool add = true;
                  auto diff_in = x^y;
                  for (unsigned b = 0; b < lenSB; ++b) if (din[b] != 2 && ((diff_in >> b) & 1) != din[b]) add = false;
                  auto diff_out = SB[x]^SB[y];
                  for (unsigned b = 0; b < lenSB; ++b) if (dout[b] != 2 && ((diff_out >> b) & 1) != dout[b]) add = false;
                  if (add) my_inputs.emplace_back(SB[x],SB[y]);
                }
              }
              set<unsigned> set_of_inputs;
              unsigned expected_size = 0;
              for (auto const & my_pair : my_inputs) {
                unsigned x = 0, i = 0;
                for (unsigned b = 0; b < lenSB; ++b) {
                  if (isKnownKeyBit((r+1)*sizeBlock + getPERM()[j*lenSB + b])) {
                    x |= ((my_pair.first >> b) & 1) << i;
                    i += 1;
                    x |= ((my_pair.second >> b) & 1) << i;
                    i += 1;
                  }
                  else {
                    x |= (((my_pair.first >> b) & 1) ^ ((my_pair.second >> b) & 1)) << i;
                    i += 1;
                  }
                }
                expected_size = i;
                set_of_inputs.emplace(x);
              }
              for (unsigned i = 0; i < lenSB; ++i) if (dout[i] != 2) expected_size -= 1;
              //cout << set_of_inputs.size() << " -- " << expected_size << endl;
              double cpt = set_of_inputs.size();
              cpt /= 1u << expected_size;

                solSboxes[ct] -= log2(cpt);
                if (!beslow || r != nrR - 1) {
                  filterSB[ct] = -log2(cpt);
                  solSboxesIn[ct] = expected_size - filterSB[ct];
                }
                else {
                  filterSB[ct] = 0;
                  solSboxesIn[ct] = expected_size;
                  Npairs += log2(cpt);
                  save_filter -= log2(cpt);
                }
               
            }
            // === Key absorption override on filter ===
            if (key_abs && getKeyAbsType() == KeyAbsType::AVERAGE) {
                if (std::find(sbox_indices.begin(), sbox_indices.end(), ct) != sbox_indices.end()) {
                    bool dout_is_zero = true;
                    for (unsigned b = 0; b < lenSB; b++) {
                        if (dout[b] != 0) { dout_is_zero = false; break; }
                    }

                    if (dout_is_zero) {
                        solSboxes[ct] -= 1.0;   // reduce for dout = 0
                    } else {
                        solSboxes[ct] = 0.0;    // force to zero for dout != 0
                    }
                }
            }
            ct++;
        }
    }
}

unsigned Cipher::getNrSol(vector <unsigned> din, vector < unsigned > dout){
    unsigned nrsol = 0;
    vector < unsigned > possible_dout = possibleVectors(dout);
    vector < unsigned > possible_din = possibleVectors(din);
    for (unsigned i = 0; i < possible_din.size(); i++){
        for (unsigned j = 0; j < possible_dout.size(); j++){
            nrsol += DDT[possible_din[i]][possible_dout[j]];
        }
    }
    return nrsol;
}


vector <unsigned> Cipher::possibleVectors(vector <unsigned> vect) const{
    vector <unsigned> res(1,0);
    for(unsigned b = 0; b < lenSB; ++b){
        if(vect[b] != 2){
            for(auto & x : res) x |= vect[b] << b;
        }
        else{
            auto tmp = res;
            for(auto x : tmp) res.emplace_back(x | (1 << b));
        }
    }
    return res;
}




bool Cipher::forceAndPropagateFromSboxUntilStable(
    unsigned sboxIndex,
    const std::vector<unsigned>& forcedDiff)
{
    unsigned bitsToZero, bitsToOne;
    std::vector<unsigned> din;
    std::vector<unsigned> dout;
    std::vector<unsigned> modified_prop((2 * nrR) * sizeBlock, 3);

    unsigned round_index      = sboxIndex / (sizeBlock / lenSB);
    unsigned sbox_local_index = sboxIndex % (sizeBlock / lenSB);

    // ---- VALIDITY CHECK HELPER ----
    auto check_valid_transition =
        [&](const std::vector<unsigned>& din_bits,
            const std::vector<unsigned>& dout_bits) -> bool
    {
        // enumerate all possibilities for din/dout
        std::vector<unsigned> possible_din  = possibleVectors(din_bits);
        std::vector<unsigned> possible_dout = possibleVectors(dout_bits);

        for (unsigned in_val : possible_din)
            for (unsigned out_val : possible_dout)
                if (DDT[in_val][out_val] != 0)
                    return true;      // at least one valid pair

        return false;                 // impossible transition
    };

    // ======================================================================
    //  CASE 1 : FIRST ROUND   (forward propagation)
    // ======================================================================
    if (round_index == 0) {

        // Force input difference
        for (unsigned i = 0; i < lenSB; ++i) {
            prop[sbox_local_index * lenSB + i] = forcedDiff[i];
            modified_prop[sbox_local_index * lenSB + i] = forcedDiff[i];
        }

        din  = getDiff(0, sbox_local_index, prop);  // S-box input
        dout = getDiff(1, sbox_local_index, prop);  // S-box output

        // ---- VALIDITY CHECK ----
        if (!check_valid_transition(din, dout))
            return false;

        bitsToZero = findBitsToZeroForwardWithOutputConstraint(din, dout);
        bitsToOne  = findBitsToOneForwardWithOutputConstraint(din, dout);

        // propagate output of S-box
        for (unsigned k = 0; k < lenSB; ++k) {
            unsigned bitIndex = sizeBlock + sbox_local_index * lenSB + k;

            if (((bitsToZero >> k) & 1) == 0) {
                prop[bitIndex] = 0;
                modified_prop[bitIndex] = 0;
            } else if (((bitsToOne >> k) & 1) == 1) {
                prop[bitIndex] = 1;
                modified_prop[bitIndex] = 1;
            }
        }

        // Other rounds before DeltaX
        if (nrSBp > 1) {
            for (unsigned j = 0; j < sizeBlock; ++j) {
                if (modified_prop[sizeBlock + j] < 2 && DKEY[sizeBlock + j] < 2) {
                    unsigned val = prop[sizeBlock + j] ^ DKEY[sizeBlock + j];
                    prop[2 * sizeBlock + PERM[j]] = val;
                    modified_prop[2 * sizeBlock + PERM[j]] = val;
                }
            }
        }

        // Propagate through layers 1...(nrSBp-1)
        for (unsigned l = 1; l < nrSBp; ++l) {

            for (unsigned j = 0; j < sizeBlock / lenSB; ++j) {

                // If something changed in this S-box, recompute din,dout
                bool modified_here = std::any_of(
                        &modified_prop[(2*l)*sizeBlock + j*lenSB],
                        &modified_prop[(2*l)*sizeBlock + j*lenSB + lenSB],
                        [](unsigned x){ return x != 3; });

                if (!modified_here) continue;

                din  = getDiff(2*l,   j, prop); // input of S-box layer l
                dout = getDiff(2*l+1, j, prop); // output of S-box layer l

                // ---- VALIDITY CHECK ----
                if (!check_valid_transition(din, dout))
                    return false;

                bitsToZero = findBitsToZeroForwardWithOutputConstraint(din, dout);
                bitsToOne  = findBitsToOneForwardWithOutputConstraint(din, dout);

                for (unsigned k = 0; k < lenSB; ++k) {
                    unsigned &cur = prop[(2*l+1)*sizeBlock + j*lenSB + k];
                    unsigned &mod = modified_prop[(2*l+1)*sizeBlock + j*lenSB + k];

                    if (((bitsToZero >> k) & 1) == 0) {
                        cur = 0; mod = 0;
                    } else if (((bitsToOne >> k) & 1) == 1) {
                        cur = 1; mod = 1;
                    }
                }
            }

            // Linear layer after this S-box layer
            if (l != nrSBp - 1) {
                for (unsigned j = 0; j < sizeBlock; ++j) {
                    if (modified_prop[(2*l+1)*sizeBlock + j] < 2 && DKEY[l*sizeBlock + j] < 2) {
                        unsigned val = prop[(2*l+1)*sizeBlock + j] ^ DKEY[l*sizeBlock + j];
                        prop[(2*l+2)*sizeBlock + PERM[j]] = val;
                        modified_prop[(2*l+2)*sizeBlock + PERM[j]] = val;
                    }
                }
            }
        }
    }

    // ======================================================================
    //  CASE 2 : LAST ROUND   (backward propagation)
    // ======================================================================
    else if (round_index == nrR - 1) {

        // Force output difference
        for (unsigned i = 0; i < lenSB; ++i) {
            prop[(2*(nrR-1)+1)*sizeBlock + sbox_local_index * lenSB + i] = forcedDiff[i];
            modified_prop[(2*(nrR-1)+1)*sizeBlock + sbox_local_index * lenSB + i] = forcedDiff[i];
        }

        // Interpret properly as input/output for the DDT check
        std::vector<unsigned> diff_in  = getDiff(2*(nrR-1),   sbox_local_index, prop); // S-box input
        std::vector<unsigned> diff_out = getDiff(2*(nrR-1)+1, sbox_local_index, prop); // S-box output

        // ---- VALIDITY CHECK ---- (input, output)
        if (!check_valid_transition(diff_in, diff_out))
            return false;

        // Backward helpers still expect (output_bits, input_bits),
        // consistent with the old working version.
        bitsToZero = findBitsToZeroBackwardWithInputConstraint(diff_out, diff_in);
        bitsToOne  = findBitsToOneBackwardWithInputConstraint(diff_out, diff_in);

        for (unsigned k = 0; k < lenSB; ++k) {
            unsigned bitIndex = 2*(nrR-1)*sizeBlock + sbox_local_index * lenSB + k;

            if (((bitsToZero >> k) & 1) == 0) {
                prop[bitIndex] = 0;
                modified_prop[bitIndex] = 0;
            } else if (((bitsToOne >> k) & 1) == 1) {
                prop[bitIndex] = 1;
                modified_prop[bitIndex] = 1;
            }
        }

        // Backward propagation through ΔY layers
        for (unsigned i = 1; i < nrSBc; ++i) {
            unsigned l = nrR - 1 - i;

            for (unsigned j = 0; j < sizeBlock / lenSB; ++j) {

                bool modified_here = std::any_of(
                        &modified_prop[(2*l+1)*sizeBlock + j*lenSB],
                        &modified_prop[(2*l+1)*sizeBlock + j*lenSB + lenSB],
                        [](unsigned x){ return x != 3; });

                if (!modified_here) continue;

                // Recompute input/output differences for this S-box
                std::vector<unsigned> diff_out_l = getDiff(2*l+1, j, prop); // S-box output
                std::vector<unsigned> diff_in_l  = getDiff(2*l,   j, prop); // S-box input

                // ---- VALIDITY CHECK ---- (input, output)
                if (!check_valid_transition(diff_in_l, diff_out_l))
                    return false;

                // Backward helpers: (output_bits, input_bits)
                bitsToZero = findBitsToZeroBackwardWithInputConstraint(diff_out_l, diff_in_l);
                bitsToOne  = findBitsToOneBackwardWithInputConstraint(diff_out_l, diff_in_l);

                for (unsigned k = 0; k < lenSB; ++k) {
                    unsigned &cur = prop[(2*l)*sizeBlock + j*lenSB + k];
                    unsigned &mod = modified_prop[(2*l)*sizeBlock + j*lenSB + k];

                    if (((bitsToZero >> k) & 1) == 0) {
                        cur = 0; mod = 0;
                    } else if (((bitsToOne >> k) & 1) == 1) {
                        cur = 1; mod = 1;
                    }
                }
            }

            if (i != nrSBc - 1) {
                for (unsigned j = 0; j < sizeBlock; ++j) {
                    if (modified_prop[(2*l)*sizeBlock + j] < 2 && DKEY[l*sizeBlock + j] < 2) {
                        unsigned val = prop[(2*l)*sizeBlock + j] ^ DKEY[l*sizeBlock + j];
                        prop[(2*l-1)*sizeBlock + InvPERM[j]] = val;
                        modified_prop[(2*l-1)*sizeBlock + InvPERM[j]] = val;
                    }
                }
            }
        }
    }

    else {
        throw std::invalid_argument(
            "forceAndPropagateFromSboxUntilStable only supports first and last round S-boxes"
        );
    }

    return true;  // everything was valid
}




void Cipher::printProp() const {
    for (unsigned t = 0; t < 2 * nrR; ++t) {
        std::cout << "Layer " << t << ": ";
        for (unsigned i = 0; i < sizeBlock; ++i)
            std::cout << prop[t * sizeBlock + i];
        std::cout << std::endl;
    }
    std::cout << std::endl;
}

unsigned Cipher::findBitsToZeroForwardWithOutputConstraint(const std::vector<unsigned>& din, const std::vector<unsigned>& dout) const {
    unsigned bitsToZero = 0;
    std::vector<unsigned> possible_din = possibleVectors(din);
    std::vector<unsigned> possible_dout = possibleVectors(dout);

    for (unsigned in : possible_din) {
        for (unsigned out : possible_dout) {
            if (DDT[in][out] != 0)
                bitsToZero |= out;
        }
    }
    return bitsToZero;
}

unsigned Cipher::findBitsToOneForwardWithOutputConstraint(const std::vector<unsigned>& din, const std::vector<unsigned>& dout) const {
    unsigned bitsToOne = sizeSB - 1;
    std::vector<unsigned> possible_din = possibleVectors(din);
    std::vector<unsigned> possible_dout = possibleVectors(dout);

    for (unsigned in : possible_din) {
        for (unsigned out : possible_dout) {
            if (DDT[in][out] != 0)
                bitsToOne &= out;
        }
    }
    return bitsToOne;
}

unsigned Cipher::findBitsToZeroBackwardWithInputConstraint(const std::vector<unsigned>& dout, const std::vector<unsigned>& din) const {
    unsigned bitsToZero = 0;
    std::vector<unsigned> possible_dout = possibleVectors(dout);
    std::vector<unsigned> possible_din = possibleVectors(din);

    for (unsigned out : possible_dout) {
        for (unsigned in : possible_din) {
            if (DDT[in][out] != 0)
                bitsToZero |= in;
        }
    }
    return bitsToZero;
}

unsigned Cipher::findBitsToOneBackwardWithInputConstraint(const std::vector<unsigned>& dout, const std::vector<unsigned>& din) const {
    unsigned bitsToOne = sizeSB - 1;
    std::vector<unsigned> possible_dout = possibleVectors(dout);
    std::vector<unsigned> possible_din = possibleVectors(din);

    for (unsigned out : possible_dout) {
        for (unsigned in : possible_din) {
            if (DDT[in][out] != 0)
                bitsToOne &= in;
        }
    }
    return bitsToOne;
}

void Cipher::setUpdatedKS(const vector<SboxAnalysisEntry>& entries) {
    
    vector<std::vector<unsigned>> new_eq;
    UpdatedKS = KS;

    
    for (const SboxAnalysisEntry& entry : entries) {
        for (const auto& guess : entry.new_bit_guess) {
            if (!guess.empty())
                new_eq.push_back(guess);
        }

        const auto& ab = entry.absorption;
        if (!ab.bit1.empty()) {
            std::vector<unsigned> absorp_eq = ab.bit1;
            if (std::find(absorp_eq.begin(), absorp_eq.end(), ab.bit2) == absorp_eq.end())
                absorp_eq.push_back(ab.bit2);
            new_eq.push_back(std::move(absorp_eq));
        } else if (ab.bit2) {
            new_eq.push_back({ab.bit2});
        }
    }
    
    UpdatedKS.insert(UpdatedKS.end(), new_eq.begin(), new_eq.end()); 
    UpdatedmatKS = Matrix(UpdatedKS);

}

void Cipher::clearKS() {
    KS.clear();              // Supprime toutes les équations
    UpdatedKS.clear();       // Par cohérence

    matKS = Matrix(KS);      // Matrice vide
    UpdatedmatKS = Matrix(KS);

    // Tous les bits deviennent “unknown” (2)
    for (unsigned i = 0; i < knownkeybits.size(); ++i)
        knownkeybits[i] = 0;   // ou 2, selon ce que tu veux dire par "unknown"
}



bool modifyCipherForKeyAbsExact(Cipher& c, const std::vector<std::vector<unsigned>>& dins, const std::vector<unsigned>& sbox_indices, const std::vector<SboxAnalysisEntry>& entries){
    
    if (sbox_indices.size() != entries.size() ||
        sbox_indices.size() != dins.size())
    {
        throw std::invalid_argument(
            "Mismatch between number of S-box indices, entries, and dins");
    }

    // Try each forced din
    for (size_t i = 0; i < sbox_indices.size(); ++i) {

        unsigned sbox_idx      = sbox_indices[i];
        const auto& entry      = entries[i];
        const auto& din_bits   = dins[i];

        // --- VALIDITY / PROPAGATION ---
        bool ok = c.forceAndPropagateFromSboxUntilStable(sbox_idx, din_bits);

        if (!ok) {
            // ❌ Impossible Δin→Δout transition detected — stop immediately
            return false;
        }
    }

    // If we reach here, all forced dins were compatible.
    c.setSboxIndices(sbox_indices);
    c.fillSb();
    c.setCurrentEntry(entries);
    c.setUpdatedKS(entries);

    return true; // all good
}



SboxAnalysisMap Cipher::prepareKeyAbsorptionExact(unsigned sbox_key_abs) {

    if (!isAllowedForKeyAbs(sbox_key_abs)) {
        throw std::invalid_argument(
            "ERROR: S-box " + std::to_string(sbox_key_abs) +
            " is not allowed for key absorption. Use one of the S-boxes printed by the tool."
        );
    }
    

    sbox_key_abs_index = sbox_key_abs;

    unsigned round_index = sbox_key_abs/(sizeBlock/lenSB);

    if (round_index == 0){

        vector<unsigned> deltain = getDiff(0, sbox_key_abs, prop);
        vector<unsigned> deltaout = getDiff(1, sbox_key_abs, prop);

        unsigned weight = 0;
        for (unsigned bit : deltaout) {
            if (bit >= 1) {
                ++weight;
            if (weight > 1) {throw std::invalid_argument("Sbox selected for key absorption has more than 1 active output bit");} 
            }
        }

        sol_map = compute_solution_map(SB, deltain, deltaout);
        //print_solution_map(sol_map, lenSB);

        analysis_map = convert_to_sbox_analysis_map(sol_map, deltaout);
        //print_sbox_analysis_map(analysis_map);

        apply_global_bit_positions(analysis_map, sbox_key_abs, lenSB, sizeBlock, PERM, InvPERM, true);
        //print_sbox_analysis_map_global(analysis_map);

        /*std::cout << "Nombre total de combinaisons (dout, din) : "
            << count_din_dout_combinations(analysis_map)
            << "\n";*/
    }
    else if (round_index == nrR - 1)
    {
        vector <unsigned> InvSB(sizeSB);
        for (unsigned i = 0; i < sizeSB; ++i) {
            InvSB[SB[i]] = i;
        }

        vector<unsigned> deltain = getDiff(2*round_index+1, sbox_key_abs%(sizeBlock/lenSB), prop);
        vector<unsigned> deltaout = getDiff(2*round_index, sbox_key_abs%(sizeBlock/lenSB), prop);


        unsigned weight = 0;
        for (unsigned bit : deltaout) {
            if (bit >= 1) {
                ++weight;
            if (weight > 1) {throw std::invalid_argument("Sbox selected for key absorption has more than 1 active output bit");} 
            }
        }

        sol_map = compute_solution_map(InvSB, deltain, deltaout);
        //print_solution_map(sol_map, lenSB);

        analysis_map = convert_to_sbox_analysis_map(sol_map, deltaout);
        //print_sbox_analysis_map(analysis_map);

        apply_global_bit_positions(analysis_map, sbox_key_abs, lenSB, sizeBlock, PERM, InvPERM, false);
        //print_sbox_analysis_map_global(analysis_map);

        /*std::cout << "Nombre total de combinaisons (dout, din) : "
            << count_din_dout_combinations(analysis_map)
            << "\n";*/
    }
    else{
        throw std::invalid_argument("Sbox selected for key absorption not on the first or last round");
    }
    return analysis_map;

}

const SboxAnalysisMap& Cipher::get_sbox_analysis_map() const {
    return analysis_map;
}

// Version minimale : on ne manipule plus de SboxAnalysisEntry ici.
// On force juste des din, on recalcule les S-boxes, et c'est tout.
bool modifyCipherForKeyAbsAverage(Cipher& c, const std::vector<std::vector<unsigned>>& dins, const std::vector<unsigned>& sbox_indices) {
    if (sbox_indices.size() != dins.size()) {
        throw std::invalid_argument("Mismatch between S-box indices and dins");
    }

    // Apply each forced din
    for (size_t i = 0; i < dins.size(); ++i) {
        if (!c.forceAndPropagateFromSboxUntilStable(sbox_indices[i], dins[i])) {
            return false; // invalid → prune
        }
    }
    //c.printProp();
    c.setSboxIndices(sbox_indices);

    c.clearKS();

    // Now fill SB tables (on the modified prop)
    c.fillSb();
    return true; // ✔ valid
}


// Nouvelle version : renvoie un SimpleSboxMap (structure "moyennée")
// qui regroupe, pour cette S-box, les din par nombre de solutions (puissance de 2).
SimpleSboxMap Cipher::prepareKeyAbsorptionAverage(unsigned sbox_key_abs) {unsigned round_index = sbox_key_abs/(sizeBlock/lenSB); unsigned local_idx   = sbox_key_abs % (sizeBlock/lenSB);

    if (!isAllowedForKeyAbs(sbox_key_abs)) {
        throw std::invalid_argument(
            "ERROR: S-box " + std::to_string(sbox_key_abs) +
            " is not allowed for key absorption. Use one of the S-boxes printed by the tool."
        );
    }
    

    if (round_index == 0) {
        // On pourrait récupérer deltain si tu en as besoin plus tard,
        // mais pour compute_simple_sbox_map on n’utilise que deltaout.
        std::vector<unsigned> deltain  = getDiff(0, sbox_key_abs, prop);
        std::vector<unsigned> deltaout = getDiff(1, sbox_key_abs, prop);

        // Ici deltaout est typiquement du style 0002, 0001, etc.
        return compute_simple_sbox_map(SB, deltaout);
    }
    else if (round_index == nrR - 1) {
        // Inverse de la S-box
        std::vector<unsigned> InvSB(sizeSB);
        for (unsigned i = 0; i < sizeSB; ++i) {
            InvSB[SB[i]] = i;
        }

        std::vector<unsigned> deltain  =
            getDiff(2*round_index+1, local_idx, prop);
        std::vector<unsigned> deltaout =
            getDiff(2*round_index,   local_idx, prop);

        return compute_simple_sbox_map(InvSB, deltaout);
    }
    else{
        throw std::invalid_argument(
            "Sbox selected for key absorption not on the first or last round"
        );
    }
}


bool Cipher::setKeyAbs(bool val){
    key_abs=val;
    return key_abs;
}

double Cipher::computeKeyAbsCorrection(const std::vector<unsigned>& sbox_indices) const {
    double correction = 0.0;
    unsigned lenSB = this->lenSB;

    for (unsigned idx : sbox_indices) {
        unsigned round_index = idx / (sizeBlock / lenSB);
        unsigned local_idx   = idx % (sizeBlock / lenSB);

        // côté plaintext : entrée
        if (round_index == 0) {
            for (unsigned b = 0; b < lenSB; ++b) {
                unsigned val = prop[local_idx * lenSB + b];
                if (val == 0 || val == 1) correction += 1.0;
            }
        }
        // côté ciphertext : sortie
        else if (round_index == nrR - 1) {
            for (unsigned b = 0; b < lenSB; ++b) {
                unsigned val = prop[(2*(nrR-1)+1)*sizeBlock + local_idx * lenSB + b];
                if (val == 0 || val == 1) correction += 1.0;
            }
        }
    }

    return correction; // nb total de bits fixés
}

bool Cipher::isAllowedForKeyAbs(unsigned sbox_index) const {
    if (std::find(allowed_first_round_sboxes.begin(),
                  allowed_first_round_sboxes.end(),
                  sbox_index) != allowed_first_round_sboxes.end())
        return true;

    if (std::find(allowed_last_round_sboxes.begin(),
                  allowed_last_round_sboxes.end(),
                  sbox_index) != allowed_last_round_sboxes.end())
        return true;

    return false;
}



