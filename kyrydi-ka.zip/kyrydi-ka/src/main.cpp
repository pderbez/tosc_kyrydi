#include <filesystem>
#include <iostream>
#include <fstream>
#include <vector>
#include <string>

#include "main.hpp"
#include "Search.hpp"
#include "Cipher.hpp"
#include "key_abs.hpp"            // run_key_absorption_exact
#include "key_abs_average.hpp"    // run_key_absorption_average

using namespace std;

// Static cipher instance for Solver
Cipher Solver::cipher;

int main(int argc, char **argv) {
    if (argc < 2) {
        cerr << "Usage: " << argv[0] << " cipher.txt [options]\n";
        cerr << "Options:\n"
             << "  -t, --time <val>       : time bound (internally shifted by +100)\n"
             << "  -m, --mem <val>        : memory bound\n"
             << "  -p, --pre <val>        : preprocessing bound\n"
             << "      --underN           : slow / underN mode\n"
             << "      --ka_exact <i...>  : exact key absorption on given S-box indices\n"
             << "      --ka_average <i...>: average key absorption on given S-box indices\n";
        return 1;
    }

    ifstream ifCipher(argv[1]);
    if (!ifCipher) {
        cerr << "ERROR: cannot open " << argv[1] << "\n";
        return 1;
    }

    double bound_time = -101.0;
    double bound_off  = -1.0;
    double bound_mem  = -101.0;
    bool   be_slow    = false;

    bool ka_exact_mode   = false;
    bool ka_average_mode = false;

    vector<unsigned> sbox_indices_exact;
    vector<unsigned> sbox_indices_average;

    // ---- parse options ----
    int u = 2;
    while (u < argc) {
        string arg = argv[u];

        if (arg == "--time" || arg == "-t") {
            if (u + 1 >= argc) {
                cerr << "Missing argument after " << arg << "\n";
                return 1;
            }
            bound_time = 100.0 + stod(argv[u + 1]);
            u += 2;
        }
        else if (arg == "--mem" || arg == "-m") {
            if (u + 1 >= argc) {
                cerr << "Missing argument after " << arg << "\n";
                return 1;
            }
            bound_mem = stod(argv[u + 1]);
            u += 2;
        }
        else if (arg == "--pre" || arg == "-p") {
            if (u + 1 >= argc) {
                cerr << "Missing argument after " << arg << "\n";
                return 1;
            }
            bound_off = stod(argv[u + 1]);
            u += 2;
        }
        else if (arg == "--underN") {
            be_slow = true;
            ++u;
        }
        else if (arg == "--ka_exact") {
            if (ka_exact_mode) {
                cerr << "Error: --ka_exact given more than once.\n";
                return 1;
            }
            ka_exact_mode = true;
            ++u;
            while (u < argc && argv[u][0] != '-') {
                sbox_indices_exact.push_back(static_cast<unsigned>(stoi(argv[u])));
                ++u;
            }
        }
        else if (arg == "--ka_average") {
            if (ka_average_mode) {
                cerr << "Error: --ka_average given more than once.\n";
                return 1;
            }
            ka_average_mode = true;
            ++u;
            while (u < argc && argv[u][0] != '-') {
                sbox_indices_average.push_back(static_cast<unsigned>(stoi(argv[u])));
                ++u;
            }
        }
        else {
            cerr << "Unknown option: " << arg << "\n";
            return 1;
        }
    }

    if (ka_exact_mode && ka_average_mode) {
        cerr << "Error: --ka_exact and --ka_average cannot be used together.\n";
        return 1;
    }

    // ---- load cipher ----
    Cipher myCipher(ifCipher, 100.0, be_slow);

    cout << "**** Step 1 : The program has read the Cipher.\n"
         << "Press 1 to print it.\n";
    int print = getchar();
    if (print == '1') {
        cout << myCipher;
        getchar();
    }

    // ---- EXACT KEY ABSORPTION MODE ----
    if (ka_exact_mode) {
        if (sbox_indices_exact.empty()) {
            cerr << "Error: --ka_exact provided but no S-box indices given.\n";
            return 1;
        }

        run_key_absorption_exact(
            myCipher,
            sbox_indices_exact,
            bound_time,
            bound_mem,
            bound_off,
            be_slow
        );
        return 0;
    }

    // ---- AVERAGE KEY ABSORPTION MODE ----
    if (ka_average_mode) {
        if (sbox_indices_average.empty()) {
            cerr << "Error: --ka_average provided but no S-box indices given.\n";
            return 1;
        }

        run_key_absorption_average(
            myCipher,
            sbox_indices_average,
            bound_time,
            bound_mem,
            bound_off,
            be_slow
        );
        return 0;
    }

    // ---------- NORMAL MODE ----------
    auto S = refine(searchBestSolver(myCipher, bound_time, bound_mem, bound_off));
    printSolverInFile("result.gv", S);
    S.printSolver();

    return 0;
}
