#ifndef KEY_ABS_HPP
#define KEY_ABS_HPP

#include <vector>
#include <map>
#include <string>
#include <algorithm>
#include <set>
#include <utility>

class Cipher;

// Struct for individual solution between input/output difference pair
struct SboxSolutions {
    unsigned x;
    unsigned y;
    unsigned partial_sx;
    unsigned partial_sy;
};

// Struct storing all SboxSolutions for a given (din, dout) pair
struct SolutionEntry {
    std::vector<SboxSolutions> solutions;
    std::vector<unsigned> key_guess;
    std::vector<unsigned> key_abs;
};

struct KeyAbsorption {
    std::vector<unsigned> bit1;
    unsigned bit2;
    unsigned sbox2_index = 0;
};

struct SboxAnalysisEntry {
    std::vector<std::vector<unsigned>> new_bit_guess;
    std::vector<unsigned> old_bit_guess;
    KeyAbsorption absorption;
    unsigned sbox_index;
};

using SboxAnalysisMap = std::map<
    std::pair<std::vector<unsigned>, std::vector<unsigned>>,
    SboxAnalysisEntry
>;

// Final map: dout -> din -> SolutionEntry
using SolutionMap = std::map<
    std::vector<unsigned>,
    std::map<std::vector<unsigned>, SolutionEntry>
>;

std::string to_binary(unsigned val, unsigned bits);
unsigned hamming_weight(unsigned x);
bool is_linearly_independent(const std::vector<unsigned>& basis, unsigned candidate);
std::vector<unsigned> expand_bits(unsigned val, unsigned bit_len);
unsigned bit_position(unsigned val);

SolutionMap compute_solution_map(
    const std::vector<unsigned>& sbox,
    const std::vector<unsigned>& deltain,
    const std::vector<unsigned>& deltaout
);
void print_solution_map(const SolutionMap& solution_map, unsigned bit_len);

SboxAnalysisMap convert_to_sbox_analysis_map(
    const SolutionMap& solution_map,
    const std::vector<unsigned>& deltaout
);
void print_sbox_analysis_map(const SboxAnalysisMap& analysis_map);

void apply_global_bit_positions(
    SboxAnalysisMap& analysis_map,
    unsigned sbox_index,
    unsigned lenSB,
    unsigned sizeBlock,
    const std::vector<unsigned>& Perm,
    const std::vector<unsigned>& InvPerm,
    bool plaintext
);

void print_sbox_analysis_map_global(const SboxAnalysisMap& analysis_map);

size_t count_din_dout_combinations(const SboxAnalysisMap& analysis_map);

// === MULTI-SBOX COMBINATIONS (CARTESIAN PRODUCT) ===
struct CombinedSboxChoice {
    std::vector<unsigned> sbox_indices;  // which S-boxes were used
    std::map<unsigned, std::pair<std::vector<unsigned>, SboxAnalysisEntry>> chosen_entries;
};

std::vector<CombinedSboxChoice> combine_sbox_maps(
    const std::vector<SboxAnalysisMap>& maps,
    const std::vector<unsigned>& sbox_indices
);

// Top-level API for main()
void run_key_absorption_exact(
    Cipher& myCipher,
    const std::vector<unsigned>& sbox_indices,
    double bound_time,
    double bound_mem,
    double bound_off,
    bool be_slow
);

#endif // KEY_ABS_HPP
