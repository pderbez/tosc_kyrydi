#include "key_abs_average.hpp"
#include "Cipher.hpp"
#include "Search.hpp"

#include <iostream>
#include <cmath>
#include <filesystem>

using namespace std;


// Test : puissance de 2 ?
static bool is_power_of_two(unsigned v) {
    return v && !(v & (v - 1));
}

// Test si un entier "dout_val" matche un pattern "deltaout" (0/1/2)
static bool dout_matches_pattern(unsigned dout_val,
                                 const std::vector<unsigned>& deltaout)
{
    unsigned len = deltaout.size();
    for (unsigned i = 0; i < len; ++i) {
        unsigned bit = (dout_val >> i) & 1u;
        if (deltaout[i] != 2 && bit != deltaout[i]) {
            return false;
        }
    }
    return true;
}

SimpleSboxMap compute_simple_sbox_map(
    const std::vector<unsigned>& sbox,
    const std::vector<unsigned>& deltaout
) {
    SimpleSboxMap result;

    unsigned len = deltaout.size();
    unsigned max_val = 1u << len;

    // din -> nb de couples (x,y) réalisant ce din ET le pattern deltaout
    std::map<unsigned, unsigned> din_counts;

    for (unsigned x = 0; x < max_val; ++x) {
        for (unsigned y = 0; y < max_val; ++y) {

            unsigned din  = x ^ y;
            unsigned dout = sbox[x] ^ sbox[y];

            // On ne garde que les dout qui respectent le pattern 0/1/2
            if (!dout_matches_pattern(dout, deltaout))
                continue;

            din_counts[din]++;
        }
    }

    // Regroupement par nb_solutions (puissances de 2)
    std::map<unsigned, std::vector<unsigned>> regroup;

    for (auto& [din, count] : din_counts) {
        if (is_power_of_two(count)) {
            regroup[count].push_back(din);
        }
    }

    if (regroup.empty()) {
        // Aucun din "intéressant"
        return result;
    }

    std::vector<SimpleDinGroup> groups;
    groups.reserve(regroup.size());

    for (auto& [count, dins] : regroup) {
        groups.push_back({count, std::move(dins)});
    }

    // On stocke le résultat sous la clé = deltaout (pattern 0/1/2)
    result[deltaout] = std::move(groups);
    return result;
}

void print_simple_sbox_map(const SimpleSboxMap& sm, unsigned len) {
    for (const auto& [dout, groups] : sm) {
        std::cout << "dout pattern = ";
        for (unsigned b : dout) std::cout << b;
        std::cout << "\n";

        for (auto& g : groups) {
            std::cout << "  nb_solutions = " << g.nb_solutions << "\n";
            std::cout << "   dins: ";
            for (unsigned din : g.dins) {
                for (unsigned i = 0; i < len; ++i)
                    std::cout << ((din >> i) & 1);
                std::cout << " ";
            }
            std::cout << "\n";
        }
        std::cout << "\n";
    }
}


// log2(a + b) from log2(a), log2(b)
static inline double add_log2(double logA, double logB) {
    if (logA == -INFINITY) return logB;
    if (logB == -INFINITY) return logA;
    double m = std::max(logA, logB);
    return m + std::log2(std::pow(2.0, logA - m) + std::pow(2.0, logB - m));
}

// int -> vector bits (LSB at index 0)
static std::vector<unsigned> to_bin_vec(unsigned x, unsigned len) {
    std::vector<unsigned> v(len);
    for (unsigned i = 0; i < len; ++i) v[i] = (x >> i) & 1u;
    return v;
}

// all combinations of {0..sizes[i]-1}
static void generate_combinations(
    const std::vector<size_t>& sizes,
    std::vector<std::vector<size_t>>& combos)
{
    if (sizes.empty()) return;

    size_t total = 1;
    for (auto s : sizes) total *= s;
    combos.reserve(total);

    size_t dims = sizes.size();
    std::vector<size_t> idx(dims, 0);

    for (;;) {
        combos.push_back(idx);
        size_t p = dims - 1;
        while (true) {
            idx[p]++;
            if (idx[p] < sizes[p]) break;
            idx[p] = 0;
            if (p == 0) return;
            p--;
        }
    }
}

// ---------------------------------------------------------------
//  FULL FUNCTION WITH CORRECTION = LOG2(total din combinations)
//  NO OTHER CHANGES
// ---------------------------------------------------------------

void run_key_absorption_average(
    Cipher& myCipher,
    const std::vector<unsigned>& sbox_indices,
    double bound_time,
    double bound_mem,
    double bound_off,
    bool be_slow
) {
    namespace fs = std::filesystem;

    // 1. Results directory
    fs::path results_dir = "results";
    if (!fs::exists(results_dir))
        fs::create_directory(results_dir);

    // Clean old .gv files
    for (auto& f : fs::directory_iterator(results_dir)) {
        if (f.path().extension() == ".gv")
            fs::remove(f.path());
    }

    // 2. Enable key absorption in the cipher
    myCipher.setKeyAbs(true);
    myCipher.setKeyAbsAverage();

    const unsigned lenSB = myCipher.getLenSB();

    // For each S-box: representative dins + log of group size
    std::vector<std::vector<unsigned>> dins_per_sbox;
    std::vector<std::vector<double>>   weights_per_sbox;
    std::vector<size_t> sizes;

    // *** NEW ***
    // store total possible din for each S-box
    std::vector<unsigned> total_din_per_sbox;
    // *** END NEW ***

    for (unsigned idx_sbox : sbox_indices) {
        SimpleSboxMap map = myCipher.prepareKeyAbsorptionAverage(idx_sbox);

        std::vector<unsigned> reps;
        std::vector<double>   logw;

        unsigned total_din_here = 0;   // *** NEW ***

        for (auto& kv : map) {
            const auto& groups = kv.second;
            for (const auto& g : groups) {
                if (g.dins.empty()) continue;
                reps.push_back(g.dins[0]);                    
                logw.push_back(std::log2(double(g.dins.size())));

                total_din_here += g.dins.size();   // *** NEW ***
            }
        }

        total_din_per_sbox.push_back(total_din_here);  // *** NEW ***

        if (reps.empty()) {
            std::cerr << "Warning: no valid din groups for S-box " << idx_sbox << "\n";
        }

        sizes.push_back(reps.size());
        dins_per_sbox.push_back(std::move(reps));
        weights_per_sbox.push_back(std::move(logw));
    }

    // 3. Cartesian product of groups over all selected S-boxes
    std::vector<std::vector<size_t>> all_combos;
    generate_combinations(sizes, all_combos);
    std::cout << "Generated " << all_combos.size() << " total combinations.\n";

    double total_timeON = -INFINITY;
    double total_nbSol  = -INFINITY;
    size_t combo_index  = 0;
    double npairs = myCipher.getNpairs();

    // 4. Process each combination
    for (const auto& choose : all_combos) {

        Cipher local = myCipher;

        std::vector<std::vector<unsigned>> dins_for_call;
        double combo_log_weight = 0.0;

        for (size_t i = 0; i < choose.size(); ++i) {
            size_t g = choose[i];
            unsigned din_int = dins_per_sbox[i][g];
            dins_for_call.push_back(to_bin_vec(din_int, lenSB));
            combo_log_weight += weights_per_sbox[i][g];
        }

        // Apply forced dins + propagation; skip invalid combos
        bool ok = modifyCipherForKeyAbsAverage(local, dins_for_call, sbox_indices);
        if (!ok) {
            ++combo_index;
            if (combo_index % 100 == 0) {
                std::cout << "\rProcessed " << combo_index << " / " << all_combos.size()
                          << std::flush;
            }
            continue;
        }

        auto S = refine(searchBestSolver(local, bound_time, bound_mem, bound_off)); 

        total_timeON = add_log2(total_timeON, combo_log_weight + S.timeON() - local.getNpairs() + npairs);
        total_nbSol  = add_log2(total_nbSol,  combo_log_weight + S.nbSols() - local.getNpairs() + npairs);

        std::string filename =
            (results_dir / ("result_" + std::to_string(combo_index) + ".gv")).string();
        printSolverInFile(filename.c_str(), S);

        ++combo_index;
        if (combo_index % 100 == 0) {
            std::cout << "\rProcessed " << combo_index << " / " << all_combos.size()
                      << std::flush;
        }
    }

    // 5. Final correction
    double correction;

    if (!be_slow) {
        double fixed_bits = myCipher.computeKeyAbsCorrection(sbox_indices);
        correction = (sbox_indices.size() * lenSB) - fixed_bits;
    } else {

        // *** NEW ***
        // correct LOG2(total din combinations)
        correction = 0.0;
        for (unsigned t : total_din_per_sbox)
            correction += std::log2(double(t));
        // *** END NEW ***
    }

    if (total_timeON != -INFINITY) total_timeON -= correction;
    if (total_nbSol  != -INFINITY) total_nbSol  -= correction;
    total_timeON = max(total_timeON, npairs);

    std::cout << "\n\n===== FINAL RESULT (average mode) =====\n";
    std::cout << "Total combinations (valid) = " << combo_index
              << " / " << all_combos.size() << "\n";
    std::cout << "Σ(timeON) corrected = N * 2 ^ " << total_timeON - npairs << "\n";
    std::cout << "Σ(nbSol)  corrected = N * 2 ^ " << total_nbSol - npairs << "\n";
    std::cout << "Correction = " << correction << "\n";

    std::ofstream summary(results_dir / "summary.txt");
    summary << "Total combinations (valid): " << combo_index
            << " / " << all_combos.size() << "\n";
    summary << "Correction: " << correction << "\n";
    summary << "Sum timeON (corrected): N * 2 ^ " << total_timeON - npairs<< "\n";
    summary << "Sum NbSol  (corrected): N * 2 ^ " << total_nbSol - npairs<< "\n";
    summary.close();
}
