#include <iostream>
#include <cmath>
#include <set>
#include <filesystem>

#include "key_abs.hpp"
#include "Cipher.hpp"
#include "Search.hpp"

using namespace std;

// Print an integer in binary on 'bits' bits
std::string to_binary(unsigned val, unsigned bits) {
    std::string out(bits, '0');
    for (unsigned i = 0; i < bits; ++i) {
        if (val & (1u << (bits - 1 - i))) out[i] = '1';
    }
    return out;
}

// Compute Hamming weight (number of 1 bits)
unsigned hamming_weight(unsigned x) {
    unsigned count = 0;
    while (x) {
        count += x & 1u;
        x >>= 1;
    }
    return count;
}

// Check if a new candidate is linearly independent from the basis
bool is_linearly_independent(const std::vector<unsigned>& basis, unsigned candidate) {
    if (candidate == 0) return false; // zéro n'ajoute jamais de rang

    std::vector<unsigned> temp = basis;
    temp.push_back(candidate);

    // Réduction style Gauss sur F2 (en version XOR/ordre bête)
    for (size_t i = 0; i < temp.size(); ++i) {
        for (size_t j = i + 1; j < temp.size(); ++j) {
            if ((temp[j] ^ temp[i]) < temp[j]) {
                temp[j] ^= temp[i];
            }
        }
    }

    size_t rank = 0;
    for (unsigned v : temp) {
        if (v != 0) ++rank;
    }

    return rank > basis.size();
}

// Décompose un entier en liste des puissances de deux actives
std::vector<unsigned> expand_bits(unsigned val, unsigned bit_len) {
    std::vector<unsigned> bits;
    for (unsigned i = 0; i < bit_len; ++i) {
        if ((val >> i) & 1u) {
            bits.push_back(1u << i);
        }
    }
    return bits;
}

// Convertit une puissance de deux en position de bit (ex: 1 -> 0, 2 -> 1, 4 -> 2, etc.)
unsigned bit_position(unsigned val) {
    unsigned pos = 0;
    while (val > 1u) {
        val >>= 1;
        ++pos;
    }
    return pos;
}

// Main function to compute all valid (x, y) pairs and their key guesses and absorptions
SolutionMap compute_solution_map(
    const std::vector<unsigned>& sbox,
    const std::vector<unsigned>& deltain,
    const std::vector<unsigned>& deltaout
) {
    SolutionMap solution_map;
    unsigned len = deltain.size();
    unsigned max_val = 1u << len;

    for (unsigned x = 0; x < max_val; ++x) {
        for (unsigned y = 0; y < max_val; ++y) {
            unsigned diff_in  = x ^ y;
            unsigned diff_out = sbox[x] ^ sbox[y];
            bool ok = true;

            std::vector<unsigned> real_din(len), real_dout(len);

            for (unsigned b = 0; b < len; ++b) {
                unsigned bit_pos = b; // LSB à gauche
                unsigned din_bit = (diff_in  >> bit_pos) & 1u;
                unsigned dout_bit = (diff_out >> bit_pos) & 1u;

                // Contrainte sur din
                if (deltain[b] == 2) {
                    real_din[b] = din_bit;
                } else if (deltain[b] == din_bit) {
                    real_din[b] = din_bit;
                } else {
                    ok = false;
                    break;
                }

                // Contrainte sur dout
                if (deltaout[b] == 2) {
                    real_dout[b] = dout_bit;
                } else if (deltaout[b] == dout_bit) {
                    real_dout[b] = dout_bit;
                } else {
                    ok = false;
                    break;
                }
            }

            if (ok) {
                unsigned partial_sx = 0, partial_sy = 0;
                // On ne garde que les bits de sortie "intéressants" (deltaout = 1 ou 2)
                for (int b = static_cast<int>(len) - 1; b >= 0; --b) {
                    if (deltaout[static_cast<size_t>(b)] == 1 ||
                        deltaout[static_cast<size_t>(b)] == 2) {
                        unsigned bit_pos = static_cast<unsigned>(b); // LSB à gauche
                        partial_sx = (partial_sx << 1)
                                   | ((sbox[x] >> bit_pos) & 1u);
                        partial_sy = (partial_sy << 1)
                                   | ((sbox[y] >> bit_pos) & 1u);
                    }
                }

                SboxSolutions sol = {x, y, partial_sx, partial_sy};
                solution_map[real_dout][real_din].solutions.push_back(sol);
            }
        }
    }

    // Fill key_guess and key_abs (générique, sauf cas spéciaux traités plus tard)
    for (auto& [dout, din_map] : solution_map) {
        for (auto& [din, entry] : din_map) {

            bool all_zero_din = std::all_of(
                din.begin(), din.end(),
                [](unsigned b) { return b == 0; }
            );
            if (all_zero_din) {
                // On laisse quand même passer, le filtrage/statut spécial
                // sera décidé dans convert_to_sbox_analysis_map si nécessaire.
            }

            std::vector<unsigned> basis_guess;
            std::vector<unsigned> basis_abs;

            for (unsigned mask = 1; mask < max_val; ++mask) {
                // --- Key guess parity ---
                bool valid_guess = true;
                bool first = true;
                unsigned expected_parity = 0;

                for (const auto& sol : entry.solutions) {
                    unsigned masked = sol.x & mask;
                    unsigned parity = hamming_weight(masked) % 2u;
                    if (first) {
                        expected_parity = parity;
                        first = false;
                    } else if (parity != expected_parity) {
                        valid_guess = false;
                        break;
                    }
                }

                if (valid_guess && is_linearly_independent(basis_guess, mask)) {
                    basis_guess.push_back(mask);
                    entry.key_guess.push_back(mask);
                }

                // --- Key absorption parity ---
                bool valid_abs = true;
                first = true;
                unsigned expected_sum = 0;

                for (const auto& sol : entry.solutions) {
                    unsigned masked = sol.x & mask;
                    unsigned parity_x = hamming_weight(masked) % 2u;
                    unsigned parity_sx = hamming_weight(sol.partial_sx) % 2u;
                    unsigned total = (parity_x + parity_sx) % 2u;

                    if (first) {
                        expected_sum = total;
                        first = false;
                    } else if (total != expected_sum) {
                        valid_abs = false;
                        break;
                    }
                }

                if (valid_abs && is_linearly_independent(basis_abs, mask)) {
                    basis_abs.push_back(mask);
                    entry.key_abs.push_back(mask);
                }
            }
        }
    }

    // On NE supprime plus les dout/din nuls ici, car on veut gérer dout = 0000 dans la phase suivante

    return solution_map;
}

// Function to print all entries of the solution map (local, non-global)
void print_solution_map(const SolutionMap& solution_map, unsigned bit_len) {
    for (const auto& [dout, din_map] : solution_map) {
        std::cout << "Dout: ";
        for (unsigned b : dout) std::cout << b << " ";
        std::cout << "\n";

        for (const auto& [din, entry] : din_map) {
            std::cout << "  Din: ";
            for (unsigned b : din) std::cout << b << " ";
            std::cout << "\n";

            for (const SboxSolutions& s : entry.solutions) {
                std::cout << "    x = " << to_binary(s.x, bit_len)
                          << ", y = " << to_binary(s.y, bit_len)
                          << ", S(x) = " << to_binary(s.partial_sx, bit_len)
                          << ", S(y) = " << to_binary(s.partial_sy, bit_len)
                          << "\n";
            }

            std::cout << "    key_guess:\n";
            for (unsigned v : entry.key_guess)
                std::cout << to_binary(v, bit_len) << " ";
            std::cout << "\n";

            std::cout << "    key_abs:\n";
            for (unsigned v : entry.key_abs)
                std::cout << to_binary(v, bit_len) << " ";
            std::cout << "\n";
        }
    }
}

/*
 * Convertit un SolutionMap (dout -> din -> solutions + masques) en SboxAnalysisMap :
 *   - new_bit_guess : listes de positions de bits pour les masques "compliqués" (non puissances de 2)
 *   - old_bit_guess : indices des bits simples (puissances de 2) considérés comme déjà connus
 *   - absorption : bit1 (liste de positions) et bit2 (position unique côté autre tour)
 *
 * Cas SPECIAL : dout == 0000
 *   - new_bit_guess = {}
 *   - old_bit_guess = {0}
 *   - absorption.bit1 = {0}
 *   - absorption.bit2 = position du bit actif dans l'autre dout (celui qui a un seul bit actif),
 *     si on arrive à le trouver, sinon 0 par défaut.
 */
SboxAnalysisMap convert_to_sbox_analysis_map(
    const SolutionMap& solution_map,
    const std::vector<unsigned>& deltaout
) {
    SboxAnalysisMap analysis_map;
    unsigned len = deltaout.size();

    // --- Pré-scan : trouver la position du bit actif du dout non-nul à poids 1 (si existe) ---
    int single_active_dout_bit_pos = -1;
    for (const auto& [dout, din_map] : solution_map) {
        bool all_zero_dout = std::all_of(
            dout.begin(), dout.end(),
            [](unsigned b) { return b == 0; }
        );
        if (all_zero_dout) continue;

        // Compter les bits à 1
        unsigned cnt = 0;
        unsigned pos = 0;
        for (unsigned i = 0; i < dout.size(); ++i) {
            if (dout[i] == 1) {
                ++cnt;
                pos = i;
            }
        }
        if (cnt == 1 && single_active_dout_bit_pos == -1) {
            single_active_dout_bit_pos = static_cast<int>(pos);
        }
    }

    // --- Conversion principale ---
    for (const auto& [dout, din_map] : solution_map) {
        bool all_zero_dout = std::all_of(
            dout.begin(), dout.end(),
            [](unsigned b) { return b == 0; }
        );

        for (const auto& [din, entry] : din_map) {
            // Cas spécial : dout = 0000...
            if (all_zero_dout) {
                SboxAnalysisEntry sbox_entry;

                // new_bit_guess vide
                sbox_entry.new_bit_guess.clear();

                // old_bit_guess = {0} (premier bit "connu")
                sbox_entry.old_bit_guess.clear();
                sbox_entry.old_bit_guess.push_back(0);

                // absorption.bit1 = {0}
                sbox_entry.absorption.bit1.clear();
                sbox_entry.absorption.bit1.push_back(0);

                // absorption.bit2 = bit actif de l'autre dout (single_active_dout_bit_pos), sinon 0
                if (single_active_dout_bit_pos >= 0) {
                    sbox_entry.absorption.bit2 = static_cast<unsigned>(single_active_dout_bit_pos);
                } else {
                    sbox_entry.absorption.bit2 = 0;
                }

                // sbox_index sera rempli plus tard par apply_global_bit_positions
                sbox_entry.sbox_index = 0;

                analysis_map[{dout, din}] = std::move(sbox_entry);
                continue;
            }

            // Cas normal : on utilise entry.key_guess / entry.key_abs
            SboxAnalysisEntry sbox_entry;
            std::set<unsigned> powers_seen;

            // new_bit_guess : masques non puissances de 2 -> convertis en positions de bits
            for (unsigned g : entry.key_guess) {
                if ((g & (g - 1)) == 0) { // puissance de 2
                    powers_seen.insert(g);
                    continue;
                }
                std::vector<unsigned> positions;
                for (unsigned i = 0; i < len; ++i) {
                    if ((g >> i) & 1u) {
                        positions.push_back(i); // LSB = index 0
                    }
                }
                if (!positions.empty()) {
                    sbox_entry.new_bit_guess.push_back(std::move(positions));
                }
            }

            // old_bit_guess : toutes les puissances de 2 non vues (présumées connues)
            for (unsigned i = 0; i < len; ++i) {
                unsigned p = 1u << i;
                if (!powers_seen.count(p)) {
                    sbox_entry.old_bit_guess.push_back(i);
                }
            }

            // absorption.bit1 : à partir du masque de poids de Hamming minimal dans key_abs
            if (!entry.key_abs.empty()) {
                auto it = std::min_element(
                    entry.key_abs.begin(), entry.key_abs.end(),
                    [](unsigned a, unsigned b) {
                        return hamming_weight(a) < hamming_weight(b);
                    }
                );
                unsigned mask = *it;
                for (unsigned i = 0; i < len; ++i) {
                    if ((mask >> i) & 1u) {
                        sbox_entry.absorption.bit1.push_back(i);  // LSB = index 0
                    }
                }
            }

            // absorption.bit2 : première position active dans deltaout (ordre LSB → MSB)
            sbox_entry.absorption.bit2 = 0;
            for (unsigned i = 0; i < deltaout.size(); ++i) {
                if (deltaout[i] == 1 || deltaout[i] == 2) {
                    sbox_entry.absorption.bit2 = i;
                    break;
                }
            }

            sbox_entry.sbox_index = 0; // sera fixé par apply_global_bit_positions
            analysis_map[{dout, din}] = std::move(sbox_entry);
        }
    }

    return analysis_map;
}

void print_sbox_analysis_map(const SboxAnalysisMap& analysis_map) {
    for (const auto& outer_pair : analysis_map) {
        const auto& dout = outer_pair.first.first;
        const auto& din  = outer_pair.first.second;
        const auto& entry = outer_pair.second;

        std::cout << "Dout: ";
        for (unsigned b : dout) std::cout << b << " ";
        std::cout << "\n";

        std::cout << "  Din: ";
        for (unsigned b : din) std::cout << b << " ";
        std::cout << "\n";

        std::cout << "    new_bit_guess:\n";
        for (const auto& vec : entry.new_bit_guess) {
            std::cout << "      { ";
            for (unsigned v : vec) std::cout << v << " ";
            std::cout << "}\n";
        }

        std::cout << "    old_bit_guess:\n";
        for (unsigned v : entry.old_bit_guess) {
            std::cout << "      " << v << "\n";
        }

        std::cout << "    absorption.bit1: { ";
        for (unsigned v : entry.absorption.bit1) std::cout << v << " ";
        std::cout << "}, bit2: " << entry.absorption.bit2 << "\n";
    }
}

void apply_global_bit_positions(
    SboxAnalysisMap& analysis_map,
    unsigned sbox_index,              // utilisé pour la position globale
    unsigned lenSB,
    unsigned sizeBlock,
    const std::vector<unsigned>& Perm,
    const std::vector<unsigned>& InvPerm,
    bool plaintext
) {
    for (auto& [key, entry] : analysis_map) {
        entry.sbox_index = sbox_index;  // affectation directe

        if (plaintext) {

            // new_bit_guess
            for (auto& guess_vec : entry.new_bit_guess) {
                for (unsigned& val : guess_vec) {
                    val = lenSB * sbox_index + val;
                }
            }

            // old_bit_guess
            for (unsigned& val : entry.old_bit_guess) {
                val = lenSB * sbox_index + val;
            }

            // absorption.bit1
            for (unsigned& val : entry.absorption.bit1) {
                val = lenSB * sbox_index + val;
            }

            // absorption.bit2 et sbox2_index
            if (!entry.absorption.bit1.empty()) {
                unsigned base_bit2 = entry.absorption.bit2;
                unsigned index_in_perm =
                    lenSB * (sbox_index % (sizeBlock / lenSB)) + base_bit2;
                if (index_in_perm < Perm.size()) {
                    entry.absorption.bit2 = Perm[index_in_perm] + sizeBlock;
                    entry.absorption.sbox2_index = entry.absorption.bit2 / lenSB;
                } else {
                    std::cerr << "Warning: Perm index out of range in apply_global_bit_positions\n";
                }
            }
        } else {
            unsigned round_index = sbox_index / (sizeBlock / lenSB);
            unsigned round_sbox_index = sbox_index % (sizeBlock / lenSB);

            // new_bit_guess
            for (auto& guess_vec : entry.new_bit_guess) {
                for (unsigned& val : guess_vec) {
                    val = Perm[lenSB * round_sbox_index + val]
                        + sizeBlock * (round_index + 1);
                }
            }

            // old_bit_guess
            for (unsigned& val : entry.old_bit_guess) {
                val = Perm[lenSB * round_sbox_index + val]
                    + sizeBlock * (round_index + 1);
            }

            // absorption.bit1
            for (unsigned& val : entry.absorption.bit1) {
                val = Perm[lenSB * round_sbox_index + val]
                    + sizeBlock * (round_index + 1);
            }

            // absorption.bit2 et sbox2_index
            if (!entry.absorption.bit1.empty()) {
                unsigned base_bit2 = entry.absorption.bit2;
                entry.absorption.bit2 =
                    base_bit2 + sizeBlock * round_index + round_sbox_index * lenSB;

                if (entry.absorption.bit2 - sizeBlock * round_index >= InvPerm.size()) {
                    std::cerr << "Warning: InvPerm index out of range in apply_global_bit_positions\n";
                } else {
                    entry.absorption.sbox2_index =
                        (InvPerm[entry.absorption.bit2 - sizeBlock * round_index]
                         + sizeBlock * (round_index - 1)) / lenSB;
                }
            }
        }
    }
}

void print_sbox_analysis_map_global(const SboxAnalysisMap& analysis_map) {
    for (const auto& [key, entry] : analysis_map) {
        const auto& dout = key.first;
        const auto& din  = key.second;

        std::cout << "Dout: ";
        for (unsigned b : dout) std::cout << b << " ";
        std::cout << "\n  Din: ";
        for (unsigned b : din) std::cout << b << " ";
        std::cout << "\n";

        std::cout << "  [GLOBAL] sbox_index: " << entry.sbox_index << "\n";

        std::cout << "    [GLOBAL] new_bit_guess:\n";
        for (const auto& vec : entry.new_bit_guess) {
            std::cout << "      { ";
            for (unsigned v : vec) std::cout << v << " ";
            std::cout << "}\n";
        }

        std::cout << "    [GLOBAL] old_bit_guess:\n";
        for (unsigned v : entry.old_bit_guess) {
            std::cout << "      " << v << "\n";
        }

        std::cout << "    [GLOBAL] absorption.bit1: { ";
        for (unsigned v : entry.absorption.bit1) std::cout << v << " ";
        std::cout << "}, bit2: " << entry.absorption.bit2
                  << ", sbox2_index: " << entry.absorption.sbox2_index << "\n";
    }
}

size_t count_din_dout_combinations(const SboxAnalysisMap& analysis_map) {
    return analysis_map.size();
}

// === MULTI-SBOX COMBINATIONS (CROSS PRODUCT) ===

// Recursive helper
static void combine_recursive(
    const std::vector<SboxAnalysisMap>& maps,
    const std::vector<unsigned>& sbox_indices,
    size_t depth,
    CombinedSboxChoice current,
    std::vector<CombinedSboxChoice>& result)
{
    if (depth == maps.size()) {
        result.push_back(std::move(current));
        return;
    }

    unsigned sbox_idx = sbox_indices[depth];
    const SboxAnalysisMap& map_here = maps[depth];

    for (const auto& [key, entry] : map_here) {
        CombinedSboxChoice next = current;
        next.sbox_indices.push_back(sbox_idx);
        next.chosen_entries[sbox_idx] = { key.second, entry };
        combine_recursive(maps, sbox_indices, depth + 1, std::move(next), result);
    }
}

std::vector<CombinedSboxChoice> combine_sbox_maps(
    const std::vector<SboxAnalysisMap>& maps,
    const std::vector<unsigned>& sbox_indices)
{
    std::vector<CombinedSboxChoice> result;
    CombinedSboxChoice current;
    combine_recursive(maps, sbox_indices, 0, std::move(current), result);
    return result;
}


// --- log2-sum helper ---
static inline double add_log2(double log_a, double log_b) {
    if (log_a == -INFINITY) return log_b;
    if (log_b == -INFINITY) return log_a;
    double m = std::max(log_a, log_b);
    return m + std::log2(std::pow(2.0, log_a - m) + std::pow(2.0, log_b - m));
}

// === Streaming recursive combination processor ===
static void process_combinations(
    const std::vector<SboxAnalysisMap>& maps,
    const std::vector<unsigned>& sbox_indices,
    size_t depth,
    CombinedSboxChoice current,
    const Cipher& base_cipher,
    double bound_time,
    double bound_mem,
    double bound_off,
    const std::filesystem::path& results_dir,
    size_t& combo_index,
    double& total_timeON,
    double& total_nbSol,
    size_t total_combinations
)
{
    if (depth == maps.size()) {
        Cipher localCipher = base_cipher;
        double npairs = base_cipher.getNpairs();

        std::vector<unsigned> all_indices = current.sbox_indices;
        std::vector<std::vector<unsigned>> all_dins;
        std::vector<SboxAnalysisEntry> all_entries;

        for (unsigned sbox_idx : current.sbox_indices) {
            const auto& chosen = current.chosen_entries.at(sbox_idx);
            all_dins.push_back(chosen.first);
            all_entries.push_back(chosen.second);
        }

        bool ok = modifyCipherForKeyAbsExact(localCipher, all_dins, all_indices, all_entries);

        if (!ok) {
            combo_index++;
            if (combo_index % 100 == 0) {
                std::cout << "\rProcessed " << combo_index << " / " << total_combinations
                          << " combinations... (Σ timeON=" << total_timeON
                          << ", Σ NbSol=" << total_nbSol << ")" << std::flush;
            }
            return;
        }

        auto solver_result = searchBestSolver(localCipher, bound_time, bound_mem, bound_off);
        auto refined = refine(solver_result);

        total_timeON = add_log2(total_timeON, refined.timeON() - localCipher.getNpairs() + npairs);
        total_nbSol  = add_log2(total_nbSol, refined.nbSols() - localCipher.getNpairs() + npairs);

        std::string filename = results_dir.string() + "/result_" + std::to_string(combo_index) + ".gv";
        printSolverInFile(filename.c_str(), refined);

        ++combo_index;
        if (combo_index % 100 == 0) {
            std::cout << "\rProcessed " << combo_index << " / " << total_combinations << std::flush;
        }

        return;
    }

    unsigned sbox_idx = sbox_indices[depth];
    for (const auto& [key, entry] : maps[depth]) {
        CombinedSboxChoice next = current;
        next.sbox_indices.push_back(sbox_idx);
        next.chosen_entries[sbox_idx] = { key.second, entry };
        process_combinations(maps, sbox_indices, depth + 1, std::move(next),
                             base_cipher, bound_time, bound_mem, bound_off,
                             results_dir, combo_index, total_timeON, total_nbSol,
                             total_combinations);
    }
}




void run_key_absorption_exact(
    Cipher& myCipher,
    const vector<unsigned>& sbox_indices,
    double bound_time,
    double bound_mem,
    double bound_off,
    bool be_slow
) {
    // 1. Create results folder
    filesystem::path results_dir = "results";
    if (!filesystem::exists(results_dir))
        filesystem::create_directory(results_dir);

    // Clean .gv files
    for (auto &f : filesystem::directory_iterator(results_dir))
        if (f.path().extension() == ".gv")
            filesystem::remove(f.path());

    // 2. Enable KeyAbs
    if (!myCipher.setKeyAbs(true)) {
        cerr << "ERROR: setKeyAbs() failed.\n";
        return;
    }
    myCipher.setKeyAbsExact();

    double npairs = myCipher.getNpairs();

    // 3. Build the analysis maps
    vector<SboxAnalysisMap> all_maps;
    for (unsigned idx : sbox_indices) {
        myCipher.prepareKeyAbsorptionExact(idx);
        all_maps.push_back(myCipher.get_sbox_analysis_map());
    }

    cout << "Starting streaming combination processing...\n";

    // 4. Process combinations (your existing recursive machinery)
    size_t total_combinations = 1;
    for (auto& m : all_maps) total_combinations *= m.size();

    size_t combo_index = 0;
    double total_timeON = 0.0;
    double total_nbSol  = 0.0;
    CombinedSboxChoice empty_choice;

    process_combinations(
        all_maps, sbox_indices,
        0, empty_choice,
        myCipher,
        bound_time, bound_mem, bound_off,
        results_dir,
        combo_index,
        total_timeON, total_nbSol,
        total_combinations
    );

    // 5. Correction
    double correction = 0.0;
    if (!be_slow) {
        double fixed_bits = myCipher.computeKeyAbsCorrection(sbox_indices);
        correction = double(sbox_indices.size() * myCipher.getLenSB()) - fixed_bits;
    } else {
        correction = log2(double(combo_index));
    }

    total_timeON -= correction;
    total_nbSol  -= correction;
    total_timeON = max(total_timeON,npairs);

    std::cout << "\n\n===== FINAL RESULT (average mode) =====\n" << combo_index << " / " << total_combinations << " combinations.\n"
         << "Σ(timeON) = N * 2 ^" << total_timeON - npairs
         << ", Σ(NbSol) = N * 2 ^" << total_nbSol - npairs
         << " (after correction " << correction << ")\n";

    ofstream summary(results_dir / "summary.txt");
    summary << "Total combinations: " << combo_index << " / " << total_combinations << "\n";
    summary << "Correction: " << correction << "\n";
    summary << "Sum timeON (corrected): N * 2 ^ " << total_timeON - npairs<< "\n";
    summary << "Sum NbSol  (corrected): N * 2 ^ " << total_nbSol - npairs<< "\n";
    summary.close();
}

