//
//  main.hpp
//  
//
//  Created by Heim on 16/06/2023.
//

#ifndef main_hpp
#define main_hpp

#include <math.h>
#include "Cipher.hpp"

/*#include "Matrix.hpp"
#include "Solver.hpp"*/

#endif /* main_hpp */
